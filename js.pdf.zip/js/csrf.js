
function setCsrfToken(token){
	
	$("#_csrf_token").val(token);

}