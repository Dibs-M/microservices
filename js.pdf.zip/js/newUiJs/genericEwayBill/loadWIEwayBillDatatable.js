$(document).ready(function() {		
	var clientId = $("#clientId").val(); 
	var secretKey = $("#secretKey").val(); 
	var userId = $("#userId").val();
	var appCode = $("#appCode").val();
	var ipUsr = $("#ipUsr").val();
	var jsonData = {"userId" : userId};

    $.ajax({
        url: 'ewaybill/getGeneratedEwayBillList',
        type : "POST",
		contentType : "application/json",
		dataType : "json",
		headers: {client_id : clientId, secret_key : secretKey, app_code : appCode,  ip_usr : ipUsr},
		data : JSON.stringify(jsonData),
		async : false,
        success : function(response) {
        	if (isValidSession(response) == 'No') {
				window.location.href = getDefaultSessionExpirePage();
				return;
			}
        	
			if(isValidToken(response) == 'No'){
				window.location.href = getCsrfErrorPage();
				return;
			}
			
        	if(response.status == 'failure'){
				//bootbox.alert(response.error_desc);
			}else{
				$.each(response, function (a, b) {
					var stat;
					if(b.ewaybillStatus=='GENEWAYBILL'){
						stat = '<span class="textColourGreen">Valid</span>';
					}else if(b.ewaybillStatus=='CANEWB'){
						stat = '<span class="textColourRed">Cancelled</span>';
					}else{
						stat = '<span class="textColourRed">Invalid</span>';
					}
					 $('#genericEwayBillTab tbody:last-child').append(
						'<tr>'
							 /*+'<td>'+(a+1)+'</td>'*/
	                		 +'<td><a href="#" onclick="javascript:viewWIEwayBillDetailedPage('+b.ewaybillNo+','+userId+');">'+b.ewaybillNo+'</a></td>'
	                		 +'<td>'+b.ewaybill_date+'</td>' 
	                		 +'<td>'+b.toTraderName+'</td>'
	                		 +'<td>'+b.transModeDesc+'</td>'
	                		 +'<td>'+stat+'</td>' 
	                		 +'<td>'+b.ewaybill_valid_upto+'</td>'
	                    +'</tr>');
	            });
			}        
        },
        error: function (data,status,er) {        	 
        	getInternalServerErrorPage();   
       }
    }); 

	createDataTable('genericEwayBillTab');
	$(".loader").fadeOut("slow");
});

function generateEWayBill(){
	$('.loader').show();	
	window.location.href = "./loginGenerateEwayBill";
	$('.loader').fadeOut("slow");
}

function viewWIEwayBillDetailedPage(idValue,userId){
	$('.loader').show();
	document.previewInvoice.action = "./getpreviewgenericewaybill";
	document.previewInvoice.id.value = idValue;
	document.previewInvoice.userId.value = userId;
	document.previewInvoice.submit();
	$('.loader').fadeOut("slow");
}
